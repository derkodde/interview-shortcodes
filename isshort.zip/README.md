# interview-shortcodes

<h2>A wordpress plugin with shortcodes for interviews and chats</h2>

<h3>caption_shortcode</h3>

<h4>simple use:</h4>    

[cap]T[/cap]est

<h4>attributes & values</h4>

<h5>default values:</h5>
Background-Color:    'color' => 'red',         --> [cap color="#DCF8C6"]T[/cap]    -> all valid CSS Color values<br/>
Style:               'style' => 'circle',      --> [cap style="square"]T[/cap]     -> "square", "circle"<br/>
Font-Color:          'text-color'=> 'white',   --> [cap text-color="#eee"]T[/cap]  -> all valid CSS Color values<br/>
Width & height       'size' => '4em',<br />
                     'font-family' => 'Georgia', <br/>
                     'hover' => 'hvr-buzz-out', <br/>

