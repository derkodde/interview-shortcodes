     new WOW().init();

jQuery(document).ready(function($){
    $('.isshort-caption').next().next().append('<div class="clearfix"></div>');
});
